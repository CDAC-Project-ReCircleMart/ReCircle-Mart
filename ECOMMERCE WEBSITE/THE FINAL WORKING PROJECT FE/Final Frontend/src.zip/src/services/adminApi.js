import api from "./api";

/* DASHBOARD */
export const getDashboardStats = () => api.get("/admin/dashboard");
export const getUsersListingsChart = () =>
  api.get("/admin/charts/users-listings");
export const getVisitsChart = () => api.get("/admin/charts/visits");
export const getCategoryChart = () => api.get("/admin/charts/categories");

/* USERS */
export const getUsers = (page, limit, search) =>
  api.get(`/admin/users?page=${page}&limit=${limit}&search=${search}`);

export const deleteUser = (id) => api.delete(`/admin/users/${id}`);

export const updateUser = (id, data) => api.put(`/admin/users/${id}`, data);

/* CALENDAR */
export const getAllEvents = () => api.get("/admin/events");
export const getEventsByDate = (date) =>
  api.get(`/admin/events/date?date=${date}`);

export const addEvent = (data) => api.post("/admin/events", data);
