import "./App.css";
import { BrowserRouter } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import Navbar from "./components/Navbar/Navbar";
import PublicRoutes from "./routes/PublicRoutes";
import { AuthProvider } from "./context/AuthContext";

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <div className="app-wrapper">
          {/* NAVBAR */}
          <Navbar />

          {/* TOAST */}
          <ToastContainer position="top-right" autoClose={3000} />

          {/* ROUTES */}
          <PublicRoutes />
        </div>
      </AuthProvider>
    </BrowserRouter>
  );
}
