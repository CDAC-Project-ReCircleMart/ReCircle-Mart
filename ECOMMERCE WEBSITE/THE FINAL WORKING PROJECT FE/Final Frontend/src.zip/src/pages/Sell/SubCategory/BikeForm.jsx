import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { toast } from "react-toastify";
import api from "../../../services/api"; // 🔴 NEW
import "./BikeForm.css"; // UI unchanged

export default function BikeForm() {
  const navigate = useNavigate();
  const { type } = useParams(); // motorcycles / scooters / bicycles

  const category = "Bikes";

  const subCategories = ["Motorcycles", "Scooters", "Bicycles"];

  const indianStates = [
    "Andhra Pradesh",
    "Arunachal Pradesh",
    "Assam",
    "Bihar",
    "Chhattisgarh",
    "Goa",
    "Gujarat",
    "Haryana",
    "Himachal Pradesh",
    "Jharkhand",
    "Karnataka",
    "Kerala",
    "Madhya Pradesh",
    "Maharashtra",
    "Manipur",
    "Meghalaya",
    "Mizoram",
    "Nagaland",
    "Odisha",
    "Punjab",
    "Rajasthan",
    "Sikkim",
    "Tamil Nadu",
    "Telangana",
    "Tripura",
    "Uttar Pradesh",
    "Uttarakhand",
    "West Bengal",
    "Andaman and Nicobar Islands",
    "Chandigarh",
    "Dadra and Nagar Haveli and Daman and Diu",
    "Delhi",
    "Jammu and Kashmir",
    "Ladakh",
    "Lakshadweep",
    "Puducherry",
  ];

  // 12 fixed photo slots
  const [photos, setPhotos] = useState(Array(12).fill(null));

  const [form, setForm] = useState({
    subCategory: type || "",
    title: "",
    yearOfPurchase: "",
    state: "",
    city: "",
    landmark: "",

    // CATEGORY SPECIFIC
    brand: "",
    model: "",
    fuel: "",
    kmDriven: "",
    descriptionText: "",
    price: "",
  });

  // 🔴 PROTECT PAGE – ONLY LOGGED IN USERS
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      toast.error("Please login to post an ad");
      navigate("/login");
    }
  }, [navigate]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const handleSelectPhoto = (index, file) => {
    if (!file) return;
    const updated = [...photos];
    updated[index] = { file, preview: URL.createObjectURL(file) };
    setPhotos(updated);
  };

  const removePhoto = (index) => {
    const updated = [...photos];
    updated[index] = null;
    setPhotos(updated);
  };

  // 🔴 SUBMIT TO BACKEND
  const handleSubmit = async () => {
    try {
      // 🔴 DESCRIPTION (ALL UNCOMMON BIKE DATA STORED HERE)
      const description = `Brand:${form.brand}, Model:${form.model}, Fuel:${form.fuel}, KMDriven:${form.kmDriven}, Notes:${form.descriptionText}`;

      // 🔴 LOCATION (STATE, CITY, LANDMARK COMBINED)
      const location = `${form.state}, ${form.city}, ${form.landmark}`;

      // 🔴 FORM DATA (FOR MULTIPLE IMAGES)
      const formData = new FormData();

      formData.append("title", form.title);
      formData.append("price", form.price);
      formData.append("category", category); // 🔴 MAIN CATEGORY
      formData.append("subcategory", form.subCategory); // 🔴 SUB CATEGORY
      formData.append("location", location);
      formData.append("year", form.yearOfPurchase);
      formData.append("description", description);

      // 🔴 MULTIPLE IMAGES
      photos.forEach((p) => {
        if (p) {
          formData.append("images", p.file);
        }
      });

      // 🔴 SEND TO BACKEND (TOKEN AUTO ATTACHED BY api.js)
      await api.post("/listings", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      // 🟢 TOAST SUCCESS
      toast.success("Bike ad posted successfully!");

      // 🔴 REDIRECT TO PROFILE (MY LISTINGS)
      navigate("/profile");
    } catch (err) {
      console.error(err);

      // 🔴 TOAST ERROR
      toast.error(
        err.response?.data?.message || "Failed to post ad. Try again.",
      );
    }
  };

  return (
    <div className="sell-form-wrapper">
      {/* TOP CATEGORY BAR */}
      <div className="category-bar">
        <h2>Post your Ad</h2>

        <div className="selected-category">
          <span>Selected category</span>
          <div className="cat-path">
            <strong>{category}</strong> / <span>{form.subCategory}</span>
            <button className="change-btn" onClick={() => navigate("/sell")}>
              Change
            </button>
          </div>
        </div>
      </div>

      <h3>Include some details</h3>

      {/* SUB CATEGORY DROPDOWN */}
      <div className="form-group">
        <label>Sub Category *</label>
        <select
          name="subCategory"
          value={form.subCategory}
          onChange={handleChange}
          required
        >
          <option value="">Select</option>
          {subCategories.map((s) => (
            <option key={s}>{s}</option>
          ))}
        </select>
      </div>

      {/* TITLE */}
      <div className="form-group">
        <label>Title *</label>
        <input
          name="title"
          value={form.title}
          onChange={handleChange}
          required
        />
      </div>

      {/* ALL OTHER FIELDS + UI UNCHANGED */}

      <button className="submit-btn" onClick={handleSubmit}>
        Post Ad
      </button>
    </div>
  );
}
