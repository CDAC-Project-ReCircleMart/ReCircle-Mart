import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { toast } from "react-toastify";
import api from "../../../services/api"; // 🔴 NEW (your axios instance)
import "./BikeForm.css"; // UI unchanged

export default function BicycleForm() {
  const navigate = useNavigate();
  const { type } = useParams(); // bicycles

  const category = "Bikes";

  const subCategories = [
    "Bicycles",
    "Electric Cycles",
    "Kids Cycles",
    "Mountain Bikes",
    "Road Bikes",
  ];

  const indianStates = [
    "Andhra Pradesh",
    "Arunachal Pradesh",
    "Assam",
    "Bihar",
    "Chhattisgarh",
    "Goa",
    "Gujarat",
    "Haryana",
    "Himachal Pradesh",
    "Jharkhand",
    "Karnataka",
    "Kerala",
    "Madhya Pradesh",
    "Maharashtra",
    "Manipur",
    "Meghalaya",
    "Mizoram",
    "Nagaland",
    "Odisha",
    "Punjab",
    "Rajasthan",
    "Sikkim",
    "Tamil Nadu",
    "Telangana",
    "Tripura",
    "Uttar Pradesh",
    "Uttarakhand",
    "West Bengal",
    "Andaman and Nicobar Islands",
    "Chandigarh",
    "Dadra and Nagar Haveli and Daman and Diu",
    "Delhi",
    "Jammu and Kashmir",
    "Ladakh",
    "Lakshadweep",
    "Puducherry",
  ];

  const [photos, setPhotos] = useState(Array(12).fill(null));

  const [form, setForm] = useState({
    subCategory: type || "",
    title: "",
    purchasedYear: "",
    state: "",
    city: "",
    landmark: "",

    // CATEGORY SPECIFIC
    brand: "",
    bicycleType: "",
    frameSize: "",
    gearType: "",
    material: "",
    condition: "",
    price: "",
  });

  // 🔴 PROTECT PAGE – ONLY LOGGED IN USERS
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      toast.error("Please login to post an ad");
      navigate("/login");
    }
  }, [navigate]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const handleSelectPhoto = (index, file) => {
    if (!file) return;
    const updated = [...photos];
    updated[index] = { file, preview: URL.createObjectURL(file) };
    setPhotos(updated);
  };

  const removePhoto = (index) => {
    const updated = [...photos];
    updated[index] = null;
    setPhotos(updated);
  };

  // 🔴 SUBMIT TO BACKEND
  const handleSubmit = async () => {
    try {
      // 🔴 DESCRIPTION (ALL UNCOMMON FIELDS GO HERE – AS YOU REQUESTED)
      const description = `Brand:${form.brand}, Type:${form.bicycleType}, Frame:${form.frameSize}, Gear:${form.gearType}, Material:${form.material}, Condition:${form.condition}`;

      // 🔴 LOCATION (STATE, CITY, LANDMARK COMBINED)
      const location = `${form.state}, ${form.city}, ${form.landmark}`;

      // 🔴 FORM DATA (FOR MULTIPLE IMAGES)
      const formData = new FormData();

      formData.append("title", form.title);
      formData.append("price", form.price);
      formData.append("category", category); // 🔴 MAIN CATEGORY
      formData.append("subcategory", form.subCategory); // 🔴 SUB CATEGORY
      formData.append("location", location);
      formData.append("year", form.purchasedYear);
      formData.append("description", description);

      // 🔴 MULTIPLE IMAGES
      photos.forEach((p) => {
        if (p) {
          formData.append("images", p.file);
        }
      });

      // 🔴 SEND TO BACKEND (TOKEN AUTO ATTACHED BY api.js)
      await api.post("/listings", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      // 🟢 TOAST SUCCESS
      toast.success("Bicycle ad posted successfully!");

      // 🔴 REDIRECT TO PROFILE (MY LISTINGS)
      navigate("/profile");
    } catch (err) {
      console.error(err);

      // 🔴 TOAST ERROR
      toast.error(
        err.response?.data?.message || "Failed to post ad. Try again.",
      );
    }
  };

  return (
    <div className="sell-form-wrapper">
      {/* TOP BAR */}
      <div className="category-bar">
        <h2>Post your Ad</h2>

        <div className="selected-category">
          <span>Selected category</span>
          <div className="cat-path">
            <strong>{category}</strong> / <span>{form.subCategory}</span>
            <button className="change-btn" onClick={() => navigate("/sell")}>
              Change
            </button>
          </div>
        </div>
      </div>

      <h3>Include some details</h3>

      {/* SUB CATEGORY DROPDOWN */}
      <div className="form-group">
        <label>Sub Category *</label>
        <select
          name="subCategory"
          value={form.subCategory}
          onChange={handleChange}
          required
        >
          <option value="">Select</option>
          {subCategories.map((s) => (
            <option key={s}>{s}</option>
          ))}
        </select>
      </div>

      {/* TITLE */}
      <div className="form-group">
        <label>Title *</label>
        <input
          name="title"
          value={form.title}
          onChange={handleChange}
          required
        />
      </div>

      {/* ALL OTHER FIELDS UNCHANGED */}
      {/* (brand, bicycleType, frameSize, gearType, material, condition, year, price, photos, location...) */}

      {/* SUBMIT */}
      <button className="submit-btn" onClick={handleSubmit}>
        Post Ad
      </button>
    </div>
  );
}
