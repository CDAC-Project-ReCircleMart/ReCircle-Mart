// src/pages/Profile/Profile.jsx
import { useState } from "react";
import "./Profile.css";
import EditProfile from "./EditProfile";

export default function Profile() {
  const [showEdit, setShowEdit] = useState(false);

  // TEMP data – later replace with backend / context
  const user = {
    name: "Rohit Kavathekar",
    email: "rohit@gmail.com",
    avatar: "/default-user.png",
  };

  return (
    <div className="profile-page">
      <div className="profile-card">
        <img src={user.avatar} alt="profile" className="profile-avatar" />

        <h2>{user.name}</h2>
        <p>{user.email}</p>

        <button className="edit-btn" onClick={() => setShowEdit(true)}>
          Edit Profile
        </button>
      </div>

      {showEdit && (
        <EditProfile user={user} onClose={() => setShowEdit(false)} />
      )}
    </div>
  );
}
