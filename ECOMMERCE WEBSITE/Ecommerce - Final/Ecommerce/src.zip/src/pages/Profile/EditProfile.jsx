// src/pages/Profile/EditProfile.jsx
import { useState } from "react";
import "./EditProfile.css";

export default function EditProfile({ user, onClose }) {
  const [name, setName] = useState(user.name);
  const [email, setEmail] = useState(user.email);
  const [password, setPassword] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();

    // later: call backend API here
    console.log({ name, email, password });

    alert("Profile updated successfully");
    onClose();
  };

  return (
    <div className="edit-overlay">
      <div className="edit-box">
        <h3>Edit Profile</h3>

        <form onSubmit={handleSubmit}>
          <input
            type="text"
            placeholder="Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />

          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />

          <input
            type="password"
            placeholder="New Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />

          <div className="edit-actions">
            <button type="submit">Save</button>
            <button type="button" onClick={onClose} className="cancel">
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
