package com.recirclemart.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "listings")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Listing {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotBlank
    private String title;

    @NotNull
    private Integer price;

    @NotBlank
    private String category;

    @NotBlank
    private String subcategory;

    @NotBlank
    @Column(columnDefinition = "TEXT")
    private String location;

    private Integer year;

    @Column(columnDefinition = "TEXT")
    private String description;

    @NotNull
    @ManyToOne
    @JoinColumn(name = "seller_id", nullable = false)
    private User seller;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;
}
