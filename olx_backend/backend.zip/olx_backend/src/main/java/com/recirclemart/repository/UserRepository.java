//package com.recirclemart.repository;
//
//import com.recirclemart.entity.User;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Query;
//
//import java.util.List;
//import java.util.Optional;
//
//public interface UserRepository extends JpaRepository<User, Integer> {
//
//    // Auth
//    Optional<User> findByEmail(String email);
//    boolean existsByEmail(String email);
//
//    // Admin dashboard
//    @Query("SELECT COUNT(u) FROM User u")
//    long countTotalUsers();
//
//    // Get all sellers (used in listings + admin)
//    List<User> findByRole(String role);
//    
//    
//    
//}




package com.recirclemart.repository;

import com.recirclemart.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
}
