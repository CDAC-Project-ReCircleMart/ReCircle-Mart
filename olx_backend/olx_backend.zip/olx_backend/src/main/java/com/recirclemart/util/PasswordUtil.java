package com.recirclemart.util;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class PasswordUtil {

    private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

    // Like bcrypt.hash(password, saltRounds)
    public String hashPassword(String rawPassword) {
        return encoder.encode(rawPassword);
    }

    // Like bcrypt.compare(password, hash)
    public boolean verifyPassword(String rawPassword, String hashedPassword) {
        return encoder.matches(rawPassword, hashedPassword);
    }
}
